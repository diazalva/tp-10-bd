-- TP10 - Pañol de herramientas
-- Ejecutar con la base panol_herramientas seleccionada en phpMyAdmin.
-- En Clever Cloud, seleccionar la base asignada al add-on antes de importar.

CREATE TABLE IF NOT EXISTS categorias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS herramientas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    marca VARCHAR(50),
    modelo VARCHAR(50),
    id_categoria INT,
    estado ENUM('Disponible', 'Prestado', 'Mantenimiento', 'Dañado') DEFAULT 'Disponible',
    fecha_adquisicion DATE,
    INDEX idx_herramientas_categoria (id_categoria),
    INDEX idx_herramientas_estado (estado),
    CONSTRAINT fk_herramientas_categoria FOREIGN KEY (id_categoria)
        REFERENCES categorias(id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS personas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    departamento VARCHAR(50),
    email VARCHAR(100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS prestamos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_herramienta INT NOT NULL,
    id_persona INT NOT NULL,
    fecha_prestamo DATE NOT NULL,
    fecha_devolucion DATE,
    observaciones TEXT,
    INDEX idx_prestamos_herramienta (id_herramienta),
    INDEX idx_prestamos_persona (id_persona),
    INDEX idx_prestamos_devolucion (fecha_devolucion),
    CONSTRAINT fk_prestamos_herramienta FOREIGN KEY (id_herramienta)
        REFERENCES herramientas(id) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_prestamos_persona FOREIGN KEY (id_persona)
        REFERENCES personas(id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos demostrativos: se agregan solo si todavía no existe el registro.
INSERT INTO categorias (nombre, descripcion)
SELECT 'Herramientas Manuales', 'Destornilladores, martillos, alicates y herramientas de mano.'
WHERE NOT EXISTS (SELECT 1 FROM categorias WHERE nombre='Herramientas Manuales');
INSERT INTO categorias (nombre, descripcion)
SELECT 'Herramientas Eléctricas', 'Taladros, amoladoras y herramientas eléctricas.'
WHERE NOT EXISTS (SELECT 1 FROM categorias WHERE nombre='Herramientas Eléctricas');
INSERT INTO categorias (nombre, descripcion)
SELECT 'Medición y Precisión', 'Instrumentos de medición y control.'
WHERE NOT EXISTS (SELECT 1 FROM categorias WHERE nombre='Medición y Precisión');

INSERT INTO personas (nombre, departamento, email)
SELECT 'Juan Pérez', 'Taller', 'juan.perez@ejemplo.com'
WHERE NOT EXISTS (SELECT 1 FROM personas WHERE nombre='Juan Pérez');
INSERT INTO personas (nombre, departamento, email)
SELECT 'María García', 'Mantenimiento', 'maria.garcia@ejemplo.com'
WHERE NOT EXISTS (SELECT 1 FROM personas WHERE nombre='María García');

INSERT INTO herramientas (nombre, marca, modelo, id_categoria, estado, fecha_adquisicion)
SELECT 'Martillo de bola', 'Stanley', 'MB-500', c.id, 'Disponible', '2024-01-15'
FROM categorias c WHERE c.nombre='Herramientas Manuales'
AND NOT EXISTS (SELECT 1 FROM herramientas WHERE nombre='Martillo de bola' AND marca='Stanley');
INSERT INTO herramientas (nombre, marca, modelo, id_categoria, estado, fecha_adquisicion)
SELECT 'Taladro percutor', 'Bosch', 'GBM 13-2', c.id, 'Disponible', '2024-03-10'
FROM categorias c WHERE c.nombre='Herramientas Eléctricas'
AND NOT EXISTS (SELECT 1 FROM herramientas WHERE nombre='Taladro percutor' AND marca='Bosch');
INSERT INTO herramientas (nombre, marca, modelo, id_categoria, estado, fecha_adquisicion)
SELECT 'Calibre digital', 'Mitutoyo', '500-196-30', c.id, 'Mantenimiento', '2024-01-30'
FROM categorias c WHERE c.nombre='Medición y Precisión'
AND NOT EXISTS (SELECT 1 FROM herramientas WHERE nombre='Calibre digital' AND marca='Mitutoyo');
