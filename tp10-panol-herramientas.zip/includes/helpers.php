<?php
declare(strict_types=1);

function e(mixed $valor): string
{
    return htmlspecialchars((string)($valor ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function csrfToken(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function verificarCsrf(): void
{
    $recibido = (string)($_POST['csrf'] ?? '');
    if (!hash_equals((string)($_SESSION['csrf'] ?? ''), $recibido)) {
        http_response_code(403);
        exit('La sesión del formulario venció. Volvé atrás y cargalo nuevamente.');
    }
}

function flash(string $tipo, string $mensaje): void
{
    $_SESSION['flash'] = ['tipo' => $tipo, 'mensaje' => $mensaje];
}

function redirigir(string $modulo): never
{
    header('Location: index.php?modulo=' . rawurlencode($modulo));
    exit;
}

function campoTexto(string $nombre, int $max, bool $obligatorio = false): ?string
{
    $valor = trim((string)($_POST[$nombre] ?? ''));
    if ($valor === '') {
        if ($obligatorio) {
            throw new InvalidArgumentException('Completá los campos obligatorios.');
        }
        return null;
    }
    if (mb_strlen($valor) > $max) {
        throw new InvalidArgumentException('El campo supera el máximo de ' . $max . ' caracteres.');
    }
    return $valor;
}

function idPost(string $nombre): int
{
    $id = filter_input(INPUT_POST, $nombre, FILTER_VALIDATE_INT);
    if (!$id || $id < 1) {
        throw new InvalidArgumentException('Seleccioná un registro válido.');
    }
    return $id;
}

function fechaPost(string $nombre, bool $obligatoria = false): ?string
{
    $valor = trim((string)($_POST[$nombre] ?? ''));
    if ($valor === '') {
        if ($obligatoria) {
            throw new InvalidArgumentException('La fecha es obligatoria.');
        }
        return null;
    }
    $fecha = DateTime::createFromFormat('!Y-m-d', $valor);
    if (!$fecha || $fecha->format('Y-m-d') !== $valor) {
        throw new InvalidArgumentException('Ingresá una fecha válida.');
    }
    return $valor;
}
