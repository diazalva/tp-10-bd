<?php
declare(strict_types=1);

/**
 * Conexión PDO a MySQL. Lee primero variables de entorno, luego un .env local
 * opcional y finalmente valores genéricos de XAMPP.
 */
function cargarEnvLocal(string $archivo): void
{
    if (!is_file($archivo) || !is_readable($archivo)) {
        return;
    }

    foreach (file($archivo, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $linea) {
        $linea = trim($linea);
        if ($linea === '' || str_starts_with($linea, '#') || !str_contains($linea, '=')) {
            continue;
        }
        [$clave, $valor] = array_map('trim', explode('=', $linea, 2));
        $valor = trim($valor, "\"'");
        if ($clave !== '' && getenv($clave) === false) {
            putenv($clave . '=' . $valor);
            $_ENV[$clave] = $valor;
        }
    }
}

cargarEnvLocal(__DIR__ . '/.env');

$host = getenv('DB_HOST') ?: '127.0.0.1';
$puerto = getenv('DB_PORT') ?: '3306';
$base = getenv('DB_NAME') ?: 'panol_herramientas';
$usuario = getenv('DB_USER') ?: 'root';
$clave = getenv('DB_PASSWORD');
$clave = $clave === false ? '' : $clave;

try {
    $pdo = new PDO(
        "mysql:host={$host};port={$puerto};dbname={$base};charset=utf8mb4",
        $usuario,
        $clave,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $error) {
    http_response_code(500);
    $detalle = htmlspecialchars($error->getMessage(), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    exit('<!doctype html><html lang="es"><meta charset="utf-8"><title>Error de conexión</title>'
        . '<body style="font:16px system-ui;max-width:760px;margin:10vh auto;padding:24px">'
        . '<h1>No se pudo conectar con MySQL</h1><p>Revisá que MySQL esté iniciado, que exista la base '
        . '<strong>' . htmlspecialchars($base, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</strong> '
        . 'y que los valores de conexión sean correctos.</p><details><summary>Detalle técnico</summary><pre>'
        . $detalle . '</pre></details><p>Consultá el paso de configuración de <code>.env</code> en README.md.</p>'
        . '</body></html>');
}
