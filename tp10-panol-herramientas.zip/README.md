# TP N.º 10 — Aplicación web para el pañol de herramientas

**Materia:** Base de Datos 1 — IPET 247 · 2026  
**Alumno:** Álvaro Díaz  
**Tecnologías:** PHP 8, MySQL, PDO, HTML, CSS y Bootstrap 5

Aplicación web para administrar el inventario y los préstamos de un pañol. Se basa en la base de datos `panol_herramientas` trabajada en el TP anterior e integra las claves foráneas de categorías, personas y préstamos.

## Funcionalidades

- **Herramientas:** alta, listado, búsqueda, edición y baja; relación con categorías y control de estado.
- **Categorías:** CRUD completo y cantidad de herramientas asociadas.
- **Personas:** CRUD completo, validación básica de correo y cantidad de préstamos asociados.
- **Préstamos:** alta, listado, edición de fechas y observaciones, baja, selección de herramienta disponible y actualización transaccional del estado de la herramienta.
- Consultas preparadas con PDO, escape de salida HTML, validación del lado del servidor y token CSRF en operaciones de escritura.
- Las claves foráneas impiden eliminar categorías, personas o herramientas que tengan registros relacionados.

## Estructura

```text
├── assets/app.css
├── includes/helpers.php
├── conexion.php
├── conexion.php.example
├── index.php
├── script_BD.sql
├── .env.example
└── .gitignore
```

## Ejecución local con XAMPP

1. Iniciá **Apache** y **MySQL** desde el Panel de Control de XAMPP.
2. En `http://localhost/phpmyadmin/`, creá una base de datos llamada `panol_herramientas` con cotejamiento `utf8mb4_unicode_ci`.
3. Seleccioná esa base e importá `script_BD.sql`. El script crea las tablas y agrega unos pocos datos demostrativos solo cuando todavía no existen.
4. Copiá la carpeta del proyecto a `C:\xampp\htdocs\tp10-panol-herramientas\`.
5. Copiá `.env.example` como `.env`. Para la instalación estándar de XAMPP, dejá `DB_HOST=127.0.0.1`, `DB_PORT=3306`, `DB_NAME=panol_herramientas`, `DB_USER=root` y `DB_PASSWORD=` si tu MySQL local no tiene contraseña. Si configuraste una clave, completala en `.env`.
6. Abrí `http://localhost/tp10-panol-herramientas/`.

También se puede configurar la conexión editando `conexion.php` o copiando `conexion.php.example`. No se deben guardar credenciales reales en el repositorio.

## Clever Cloud

Configurá `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER` y `DB_PASSWORD` como variables de entorno del servicio de PHP. Importá `script_BD.sql` en la base MySQL que asigna Clever Cloud y usá los valores de conexión de ese entorno. El nombre local `panol_herramientas` puede diferir del nombre de base que asigna Clever Cloud.

No subas `.env`, contraseñas, URI de conexión ni capturas que las muestren. El repositorio incluye únicamente valores genéricos de ejemplo.

## Captura de la aplicación

Se incluye ssets/captura-aplicacion.png con la pantalla principal de la aplicación funcionando en local.
## Entregables preparados

- Código fuente, configuración de ejemplo, script de base de datos y esta documentación para el repositorio.
- Plantilla de texto para Classroom y borrador de declaración de IA en archivos separados del proyecto público.

La publicación en GitHub y la entrega en Classroom se completan desde las cuentas del alumno. Antes de publicar, revisá el repositorio y completá por separado el texto privado de Classroom con los datos requeridos por la consigna.

