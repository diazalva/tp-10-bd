<?php
declare(strict_types=1);
session_start();
require __DIR__ . '/includes/helpers.php';
require __DIR__ . '/conexion.php';

$modulos = [
    'herramientas' => ['titulo' => 'Herramientas', 'singular' => 'herramienta', 'icono' => 'bi-tools'],
    'categorias' => ['titulo' => 'Categorías', 'singular' => 'categoría', 'icono' => 'bi-grid'],
    'personas' => ['titulo' => 'Personas', 'singular' => 'persona', 'icono' => 'bi-people'],
    'prestamos' => ['titulo' => 'Préstamos', 'singular' => 'préstamo', 'icono' => 'bi-arrow-left-right'],
];
$modulo = (string)($_GET['modulo'] ?? $_POST['modulo'] ?? 'herramientas');
if (!isset($modulos[$modulo])) {
    $modulo = 'herramientas';
}
$estados = ['Disponible', 'Prestado', 'Mantenimiento', 'Dañado'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verificarCsrf();
    $accion = (string)($_POST['accion'] ?? '');
    try {
        if ($accion === 'eliminar') {
            $id = idPost('id');
            if ($modulo === 'prestamos') {
                $pdo->beginTransaction();
                $q = $pdo->prepare('SELECT id_herramienta, fecha_devolucion FROM prestamos WHERE id = ? FOR UPDATE');
                $q->execute([$id]);
                $prestamo = $q->fetch();
                if (!$prestamo) {
                    throw new InvalidArgumentException('El préstamo ya no existe.');
                }
                if ($prestamo['fecha_devolucion'] === null) {
                    $q = $pdo->prepare("SELECT COUNT(*) FROM prestamos WHERE id_herramienta = ? AND fecha_devolucion IS NULL AND id <> ?");
                    $q->execute([$prestamo['id_herramienta'], $id]);
                    if ((int)$q->fetchColumn() === 0) {
                        $pdo->prepare("UPDATE herramientas SET estado = 'Disponible' WHERE id = ? AND estado = 'Prestado'")
                            ->execute([$prestamo['id_herramienta']]);
                    }
                }
                $pdo->prepare('DELETE FROM prestamos WHERE id = ?')->execute([$id]);
                $pdo->commit();
            } else {
                $tabla = ['herramientas' => 'herramientas', 'categorias' => 'categorias', 'personas' => 'personas'][$modulo];
                $pdo->prepare("DELETE FROM {$tabla} WHERE id = ?")->execute([$id]);
            }
            flash('success', ucfirst($modulos[$modulo]['singular']) . ' eliminado correctamente.');
            redirigir($modulo);
        }

        if ($accion !== 'guardar') {
            throw new InvalidArgumentException('La acción solicitada no es válida.');
        }
        $id = (int)($_POST['id'] ?? 0);
        if ($id < 0) {
            throw new InvalidArgumentException('El identificador no es válido.');
        }

        if ($modulo === 'herramientas') {
            $nombre = campoTexto('nombre', 100, true);
            $marca = campoTexto('marca', 50);
            $modelo = campoTexto('modelo', 50);
            $categoria = trim((string)($_POST['id_categoria'] ?? ''));
            $categoria = $categoria === '' ? null : (int)$categoria;
            if ($categoria !== null && $categoria < 1) {
                throw new InvalidArgumentException('Seleccioná una categoría válida.');
            }
            $estado = (string)($_POST['estado'] ?? 'Disponible');
            if (!in_array($estado, $estados, true)) {
                throw new InvalidArgumentException('Seleccioná un estado válido.');
            }
            $fecha = fechaPost('fecha_adquisicion');
            $datos = [$nombre, $marca, $modelo, $categoria, $estado, $fecha];
            if ($id > 0) {
                $q = $pdo->prepare('SELECT COUNT(*) FROM prestamos WHERE id_herramienta=? AND fecha_devolucion IS NULL');
                $q->execute([$id]);
                if ((int)$q->fetchColumn() > 0 && $estado !== 'Prestado') {
                    throw new InvalidArgumentException('La herramienta tiene un préstamo abierto y debe conservar el estado Prestado.');
                }
                $pdo->prepare('UPDATE herramientas SET nombre=?, marca=?, modelo=?, id_categoria=?, estado=?, fecha_adquisicion=? WHERE id=?')->execute([...$datos, $id]);
            } else {
                $pdo->prepare('INSERT INTO herramientas (nombre, marca, modelo, id_categoria, estado, fecha_adquisicion) VALUES (?,?,?,?,?,?)')->execute($datos);
            }
        } elseif ($modulo === 'categorias') {
            $nombre = campoTexto('nombre', 100, true);
            $descripcion = campoTexto('descripcion', 500);
            if ($id > 0) {
                $pdo->prepare('UPDATE categorias SET nombre=?, descripcion=? WHERE id=?')->execute([$nombre, $descripcion, $id]);
            } else {
                $pdo->prepare('INSERT INTO categorias (nombre, descripcion) VALUES (?,?)')->execute([$nombre, $descripcion]);
            }
        } elseif ($modulo === 'personas') {
            $nombre = campoTexto('nombre', 100, true);
            $departamento = campoTexto('departamento', 50);
            $email = campoTexto('email', 100);
            if ($email !== null && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new InvalidArgumentException('Ingresá un correo electrónico válido.');
            }
            if ($id > 0) {
                $pdo->prepare('UPDATE personas SET nombre=?, departamento=?, email=? WHERE id=?')->execute([$nombre, $departamento, $email, $id]);
            } else {
                $pdo->prepare('INSERT INTO personas (nombre, departamento, email) VALUES (?,?,?)')->execute([$nombre, $departamento, $email]);
            }
        } elseif ($modulo === 'prestamos') {
            $fechaPrestamo = fechaPost('fecha_prestamo', true);
            $observaciones = campoTexto('observaciones', 1000);
            $pdo->beginTransaction();
            if ($id === 0) {
                $herramienta = idPost('id_herramienta');
                $persona = idPost('id_persona');
                $q = $pdo->prepare('SELECT estado FROM herramientas WHERE id = ? FOR UPDATE');
                $q->execute([$herramienta]);
                if ($q->fetchColumn() !== 'Disponible') {
                    throw new InvalidArgumentException('La herramienta debe estar disponible para registrar un préstamo.');
                }
                $q = $pdo->prepare('SELECT COUNT(*) FROM prestamos WHERE id_herramienta = ? AND fecha_devolucion IS NULL');
                $q->execute([$herramienta]);
                if ((int)$q->fetchColumn() > 0) {
                    throw new InvalidArgumentException('La herramienta ya tiene un préstamo abierto.');
                }
                $pdo->prepare('INSERT INTO prestamos (id_herramienta, id_persona, fecha_prestamo, fecha_devolucion, observaciones) VALUES (?,?,?,NULL,?)')
                    ->execute([$herramienta, $persona, $fechaPrestamo, $observaciones]);
                $pdo->prepare("UPDATE herramientas SET estado = 'Prestado' WHERE id = ?")->execute([$herramienta]);
            } else {
                $q = $pdo->prepare('SELECT id_herramienta, fecha_devolucion FROM prestamos WHERE id=? FOR UPDATE');
                $q->execute([$id]);
                $actual = $q->fetch();
                if (!$actual) {
                    throw new InvalidArgumentException('El préstamo ya no existe.');
                }
                $fechaDevolucion = fechaPost('fecha_devolucion');
                if ($fechaDevolucion !== null && $fechaDevolucion < $fechaPrestamo) {
                    throw new InvalidArgumentException('La devolución no puede ser anterior al préstamo.');
                }
                $abiertoAntes = $actual['fecha_devolucion'] === null;
                $abiertoAhora = $fechaDevolucion === null;
                if ($abiertoAntes !== $abiertoAhora) {
                    $herramienta = (int)$actual['id_herramienta'];
                    if ($abiertoAhora) {
                        $q = $pdo->prepare('SELECT estado FROM herramientas WHERE id=? FOR UPDATE');
                        $q->execute([$herramienta]);
                        if ($q->fetchColumn() !== 'Disponible') {
                            throw new InvalidArgumentException('No se puede reabrir: la herramienta no está disponible.');
                        }
                        $pdo->prepare("UPDATE herramientas SET estado='Prestado' WHERE id=?")->execute([$herramienta]);
                    } else {
                        $q = $pdo->prepare('SELECT COUNT(*) FROM prestamos WHERE id_herramienta=? AND fecha_devolucion IS NULL AND id<>?');
                        $q->execute([$herramienta, $id]);
                        if ((int)$q->fetchColumn() === 0) {
                            $pdo->prepare("UPDATE herramientas SET estado='Disponible' WHERE id=? AND estado='Prestado'")->execute([$herramienta]);
                        }
                    }
                }
                $pdo->prepare('UPDATE prestamos SET fecha_prestamo=?, fecha_devolucion=?, observaciones=? WHERE id=?')
                    ->execute([$fechaPrestamo, $fechaDevolucion, $observaciones, $id]);
            }
            $pdo->commit();
        }
        flash('success', ucfirst($modulos[$modulo]['singular']) . ($id > 0 ? ' actualizado' : ' agregado') . ' correctamente.');
    } catch (InvalidArgumentException $error) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('danger', $error->getMessage());
    } catch (PDOException $error) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $mensaje = $error->getCode() === '23000'
            ? 'No se puede completar la operación porque existen registros relacionados.'
            : 'Ocurrió un error al guardar. Revisá los datos e intentá nuevamente.';
        flash('danger', $mensaje);
    }
    redirigir($modulo);
}

$accionVista = (string)($_GET['accion'] ?? 'listar');
$idVista = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT) ?: 0;
$busqueda = trim((string)($_GET['q'] ?? ''));
$categorias = $pdo->query('SELECT id, nombre FROM categorias ORDER BY nombre')->fetchAll();
$personas = $pdo->query('SELECT id, nombre FROM personas ORDER BY nombre')->fetchAll();
$herramientasDisponibles = $pdo->query("SELECT id, nombre, marca, estado FROM herramientas WHERE estado='Disponible' ORDER BY nombre")->fetchAll();
$registro = null;
if (in_array($accionVista, ['nuevo', 'editar'], true) && $idVista > 0) {
    if ($modulo === 'prestamos') {
        $q = $pdo->prepare('SELECT pr.*, h.nombre AS herramienta_nombre, p.nombre AS persona_nombre FROM prestamos pr JOIN herramientas h ON h.id=pr.id_herramienta JOIN personas p ON p.id=pr.id_persona WHERE pr.id=?');
    } else {
        $tabla = ['herramientas' => 'herramientas', 'categorias' => 'categorias', 'personas' => 'personas'][$modulo];
        $q = $pdo->prepare("SELECT * FROM {$tabla} WHERE id=?");
    }
    $q->execute([$idVista]);
    $registro = $q->fetch() ?: null;
}
$formulario = $accionVista === 'nuevo' || ($accionVista === 'editar' && $registro !== null);
$busquedaLike = '%' . $busqueda . '%';
if ($modulo === 'herramientas') {
    $q = $pdo->prepare('SELECT h.*, c.nombre AS categoria FROM herramientas h LEFT JOIN categorias c ON c.id=h.id_categoria WHERE h.nombre LIKE ? OR h.marca LIKE ? OR h.modelo LIKE ? OR c.nombre LIKE ? ORDER BY h.id DESC');
    $q->execute([$busquedaLike, $busquedaLike, $busquedaLike, $busquedaLike]);
    $registros = $q->fetchAll();
} elseif ($modulo === 'categorias') {
    $q = $pdo->prepare('SELECT c.*, (SELECT COUNT(*) FROM herramientas h WHERE h.id_categoria=c.id) AS total_herramientas FROM categorias c WHERE c.nombre LIKE ? OR c.descripcion LIKE ? ORDER BY c.nombre');
    $q->execute([$busquedaLike, $busquedaLike]);
    $registros = $q->fetchAll();
} elseif ($modulo === 'personas') {
    $q = $pdo->prepare('SELECT p.*, (SELECT COUNT(*) FROM prestamos pr WHERE pr.id_persona=p.id) AS total_prestamos FROM personas p WHERE p.nombre LIKE ? OR p.departamento LIKE ? OR p.email LIKE ? ORDER BY p.nombre');
    $q->execute([$busquedaLike, $busquedaLike, $busquedaLike]);
    $registros = $q->fetchAll();
} else {
    $sql = 'SELECT pr.*, h.nombre AS herramienta, h.marca, p.nombre AS persona FROM prestamos pr JOIN herramientas h ON h.id=pr.id_herramienta JOIN personas p ON p.id=pr.id_persona WHERE h.nombre LIKE ? OR p.nombre LIKE ? OR pr.observaciones LIKE ? ORDER BY (pr.fecha_devolucion IS NULL) DESC, pr.fecha_prestamo DESC';
    $q = $pdo->prepare($sql);
    $q->execute([$busquedaLike, $busquedaLike, $busquedaLike]);
    $registros = $q->fetchAll();
}
$conteos = [
    'herramientas' => (int)$pdo->query('SELECT COUNT(*) FROM herramientas')->fetchColumn(),
    'disponibles' => (int)$pdo->query("SELECT COUNT(*) FROM herramientas WHERE estado='Disponible'")->fetchColumn(),
    'personas' => (int)$pdo->query('SELECT COUNT(*) FROM personas')->fetchColumn(),
    'prestamos' => (int)$pdo->query('SELECT COUNT(*) FROM prestamos WHERE fecha_devolucion IS NULL')->fetchColumn(),
];
$flashMensaje = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);
$titulo = $modulos[$modulo]['titulo'];
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Aplicación web CRUD para administrar el pañol de herramientas.">
    <title><?= e($titulo) ?> | Pañol Central</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="assets/app.css" rel="stylesheet">
</head>
<body>
<div class="app-shell">
    <aside class="sidebar">
        <a class="brand" href="index.php"><span class="brand-mark"><i class="bi bi-box-seam"></i></span><span><b>Pañol</b><small>Control de herramientas</small></span></a>
        <div class="nav-label">GESTIÓN</div>
        <?php foreach ($modulos as $clave => $info): ?>
            <a class="side-link <?= $modulo === $clave ? 'active' : '' ?>" href="?modulo=<?= e($clave) ?>"><i class="bi <?= e($info['icono']) ?>"></i><span><?= e($info['titulo']) ?></span><?php if ($clave === 'prestamos' && $conteos['prestamos'] > 0): ?><em><?= $conteos['prestamos'] ?></em><?php endif; ?></a>
        <?php endforeach; ?>
        <div class="sidebar-footer"><span class="status-dot"></span> Sistema de pañol <small>Base de Datos 1 · 2026</small></div>
    </aside>
    <main class="main-area">
        <header class="topbar"><div><span class="eyebrow">PANEL DE ADMINISTRACIÓN</span><h1><?= e($formulario ? ($accionVista === 'editar' ? 'Editar ' : 'Nuevo/a ') . $modulos[$modulo]['singular'] : $titulo) ?></h1></div><div class="topbar-user"><span class="avatar"><i class="bi bi-person-fill"></i></span><span><b>Administrador</b><small>Gestión del pañol</small></span></div></header>
        <section class="content-area">
            <?php if ($flashMensaje): ?><div class="alert alert-<?= e($flashMensaje['tipo']) ?> alert-dismissible fade show" role="alert"><?= e($flashMensaje['mensaje']) ?><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button></div><?php endif; ?>
            <?php if (!$formulario): ?>
                <div class="stats-grid">
                    <article class="stat-card"><span class="stat-icon blue"><i class="bi bi-tools"></i></span><div><small>Herramientas</small><strong><?= $conteos['herramientas'] ?></strong><span>registradas</span></div></article>
                    <article class="stat-card"><span class="stat-icon green"><i class="bi bi-check2-circle"></i></span><div><small>Disponibles</small><strong><?= $conteos['disponibles'] ?></strong><span>listas para usar</span></div></article>
                    <article class="stat-card"><span class="stat-icon violet"><i class="bi bi-people"></i></span><div><small>Personas</small><strong><?= $conteos['personas'] ?></strong><span>autorizadas</span></div></article>
                    <article class="stat-card"><span class="stat-icon amber"><i class="bi bi-arrow-left-right"></i></span><div><small>Préstamos abiertos</small><strong><?= $conteos['prestamos'] ?></strong><span>pendientes de devolución</span></div></article>
                </div>
                <div class="panel table-panel">
                    <div class="panel-heading"><div><span class="eyebrow">REGISTROS DEL PAÑOL</span><h2><?= e($titulo) ?></h2><p>Administrá la información y mantené actualizado el inventario.</p></div><a class="btn btn-primary" href="?modulo=<?= e($modulo) ?>&accion=nuevo"><i class="bi bi-plus-lg"></i> Agregar <?= e($modulos[$modulo]['singular']) ?></a></div>
                    <form class="search-row" method="get"><input type="hidden" name="modulo" value="<?= e($modulo) ?>"><label class="search-box"><i class="bi bi-search"></i><input type="search" name="q" value="<?= e($busqueda) ?>" placeholder="Buscar en <?= e(mb_strtolower($titulo)) ?>…"></label><button class="btn btn-outline-secondary" type="submit">Buscar</button><?php if ($busqueda !== ''): ?><a class="btn btn-light" href="?modulo=<?= e($modulo) ?>">Limpiar</a><?php endif; ?></form>
                    <div class="table-responsive"><table class="table align-middle data-table"><thead><tr>
                        <?php if ($modulo === 'herramientas'): ?><th>Herramienta</th><th>Marca / modelo</th><th>Categoría</th><th>Estado</th><th>Adquisición</th>
                        <?php elseif ($modulo === 'categorias'): ?><th>Categoría</th><th>Descripción</th><th>Herramientas</th>
                        <?php elseif ($modulo === 'personas'): ?><th>Persona</th><th>Departamento</th><th>Correo</th><th>Préstamos</th>
                        <?php else: ?><th>Herramienta</th><th>Responsable</th><th>Fecha de préstamo</th><th>Devolución</th><th>Observaciones</th><?php endif; ?><th class="text-end">Acciones</th></tr></thead><tbody>
                        <?php foreach ($registros as $fila): ?><tr>
                            <?php if ($modulo === 'herramientas'): ?><td><b><?= e($fila['nombre']) ?></b><small class="cell-sub">ID #<?= (int)$fila['id'] ?></small></td><td><?= e(trim(($fila['marca'] ?? '') . ' ' . ($fila['modelo'] ?? '')) ?: '—') ?></td><td><?= e($fila['categoria'] ?? 'Sin categoría') ?></td><td><span class="badge-status <?= e(strtolower($fila['estado'])) ?>"><?= e($fila['estado']) ?></span></td><td><?= e($fila['fecha_adquisicion'] ?: '—') ?></td>
                            <?php elseif ($modulo === 'categorias'): ?><td><b><?= e($fila['nombre']) ?></b><small class="cell-sub">ID #<?= (int)$fila['id'] ?></small></td><td class="text-muted"><?= e($fila['descripcion'] ?: 'Sin descripción') ?></td><td><span class="count-pill"><?= (int)$fila['total_herramientas'] ?></span></td>
                            <?php elseif ($modulo === 'personas'): ?><td><b><?= e($fila['nombre']) ?></b><small class="cell-sub">ID #<?= (int)$fila['id'] ?></small></td><td><?= e($fila['departamento'] ?: '—') ?></td><td><?= e($fila['email'] ?: '—') ?></td><td><span class="count-pill"><?= (int)$fila['total_prestamos'] ?></span></td>
                            <?php else: ?><td><b><?= e($fila['herramienta']) ?></b><small class="cell-sub"><?= e($fila['marca'] ?: 'Sin marca') ?></small></td><td><?= e($fila['persona']) ?></td><td><?= e($fila['fecha_prestamo']) ?></td><td><?php if ($fila['fecha_devolucion'] === null): ?><span class="badge-status prestado">Pendiente</span><?php else: ?><?= e($fila['fecha_devolucion']) ?><?php endif; ?></td><td class="text-muted"><?= e($fila['observaciones'] ?: '—') ?></td><?php endif; ?>
                            <td class="text-end actions"><a class="icon-button" title="Editar" aria-label="Editar" href="?modulo=<?= e($modulo) ?>&accion=editar&id=<?= (int)$fila['id'] ?>"><i class="bi bi-pencil-square"></i></a><form method="post" class="inline-form" onsubmit="return confirm('¿Eliminar este registro? Esta acción no se puede deshacer.');"><input type="hidden" name="csrf" value="<?= e(csrfToken()) ?>"><input type="hidden" name="modulo" value="<?= e($modulo) ?>"><input type="hidden" name="accion" value="eliminar"><input type="hidden" name="id" value="<?= (int)$fila['id'] ?>"><button class="icon-button danger" title="Eliminar" aria-label="Eliminar" type="submit"><i class="bi bi-trash3"></i></button></form></td>
                        </tr><?php endforeach; ?>
                        <?php if (!$registros): ?><tr><td colspan="6" class="empty-state"><i class="bi bi-inbox"></i><b>No hay registros para mostrar</b><span>Probá con otra búsqueda o agregá el primer registro.</span></td></tr><?php endif; ?>
                    </tbody></table></div><div class="table-foot"><span><?= count($registros) ?> registro<?= count($registros) === 1 ? '' : 's' ?><?= $busqueda !== '' ? ' encontrados' : '' ?></span><span>Los cambios se guardan en MySQL</span></div>
                </div>
            <?php else: ?>
                <div class="panel form-panel"><div class="panel-heading"><div><span class="eyebrow">DATOS DEL REGISTRO</span><h2><?= e($accionVista === 'editar' ? 'Modificá la información' : 'Completá los campos') ?></h2><p>Los campos marcados con <b>*</b> son obligatorios.</p></div></div>
                    <?php if ($accionVista === 'editar' && !$registro): ?><div class="alert alert-warning">El registro solicitado no existe.</div><?php else: ?>
                    <form method="post" class="record-form"><input type="hidden" name="csrf" value="<?= e(csrfToken()) ?>"><input type="hidden" name="modulo" value="<?= e($modulo) ?>"><input type="hidden" name="accion" value="guardar"><input type="hidden" name="id" value="<?= (int)($registro['id'] ?? 0) ?>">
                        <?php if ($modulo === 'herramientas'): ?>
                            <div class="row g-3"><div class="col-md-6"><label class="form-label">Nombre *</label><input class="form-control" name="nombre" maxlength="100" required value="<?= e($registro['nombre'] ?? '') ?>"></div><div class="col-md-3"><label class="form-label">Marca</label><input class="form-control" name="marca" maxlength="50" value="<?= e($registro['marca'] ?? '') ?>"></div><div class="col-md-3"><label class="form-label">Modelo</label><input class="form-control" name="modelo" maxlength="50" value="<?= e($registro['modelo'] ?? '') ?>"></div><div class="col-md-4"><label class="form-label">Categoría</label><select class="form-select" name="id_categoria"><option value="">Sin categoría</option><?php foreach ($categorias as $cat): ?><option value="<?= (int)$cat['id'] ?>" <?= (string)($registro['id_categoria'] ?? '') === (string)$cat['id'] ? 'selected' : '' ?>><?= e($cat['nombre']) ?></option><?php endforeach; ?></select></div><div class="col-md-4"><label class="form-label">Estado *</label><select class="form-select" name="estado" required><?php foreach ($estados as $estado): ?><option <?= ($registro['estado'] ?? 'Disponible') === $estado ? 'selected' : '' ?>><?= e($estado) ?></option><?php endforeach; ?></select></div><div class="col-md-4"><label class="form-label">Fecha de adquisición</label><input class="form-control" type="date" name="fecha_adquisicion" value="<?= e($registro['fecha_adquisicion'] ?? '') ?>"></div></div>
                        <?php elseif ($modulo === 'categorias'): ?>
                            <div class="row g-3"><div class="col-md-6"><label class="form-label">Nombre *</label><input class="form-control" name="nombre" maxlength="100" required value="<?= e($registro['nombre'] ?? '') ?>"></div><div class="col-12"><label class="form-label">Descripción</label><textarea class="form-control" name="descripcion" rows="4" maxlength="500"><?= e($registro['descripcion'] ?? '') ?></textarea></div></div>
                        <?php elseif ($modulo === 'personas'): ?>
                            <div class="row g-3"><div class="col-md-6"><label class="form-label">Nombre y apellido *</label><input class="form-control" name="nombre" maxlength="100" required value="<?= e($registro['nombre'] ?? '') ?>"></div><div class="col-md-6"><label class="form-label">Departamento</label><input class="form-control" name="departamento" maxlength="50" value="<?= e($registro['departamento'] ?? '') ?>"></div><div class="col-md-6"><label class="form-label">Correo electrónico</label><input class="form-control" type="email" name="email" maxlength="100" value="<?= e($registro['email'] ?? '') ?>"></div></div>
                            <?php else: ?>
                            <?php if (!$registro): ?><div class="row g-3"><div class="col-md-6"><label class="form-label">Herramienta *</label><select class="form-select" name="id_herramienta" required><option value="">Seleccionar herramienta disponible</option><?php foreach ($herramientasDisponibles as $h): ?><option value="<?= (int)$h['id'] ?>"><?= e($h['nombre'] . ($h['marca'] ? ' · ' . $h['marca'] : '')) ?></option><?php endforeach; ?></select><?php if (!$herramientasDisponibles): ?><div class="form-text">No hay herramientas disponibles. Revisá el estado del inventario.</div><?php endif; ?></div><div class="col-md-6"><label class="form-label">Persona responsable *</label><select class="form-select" name="id_persona" required><option value="">Seleccionar persona</option><?php foreach ($personas as $persona): ?><option value="<?= (int)$persona['id'] ?>"><?= e($persona['nombre']) ?></option><?php endforeach; ?></select></div><div class="col-md-4"><label class="form-label">Fecha del préstamo *</label><input class="form-control" type="date" name="fecha_prestamo" required value="<?= e(date('Y-m-d')) ?>"></div><div class="col-12"><label class="form-label">Observaciones</label><textarea class="form-control" name="observaciones" rows="3" maxlength="1000"></textarea></div></div><?php else: ?><div class="loan-summary"><div><small>Herramienta</small><b><?= e($registro['herramienta_nombre']) ?></b></div><div><small>Responsable</small><b><?= e($registro['persona_nombre']) ?></b></div></div><div class="row g-3"><div class="col-md-4"><label class="form-label">Fecha del préstamo *</label><input class="form-control" type="date" name="fecha_prestamo" required value="<?= e($registro['fecha_prestamo']) ?>"></div><div class="col-md-4"><label class="form-label">Fecha de devolución</label><input class="form-control" type="date" name="fecha_devolucion" value="<?= e($registro['fecha_devolucion'] ?? '') ?>"><div class="form-text">Dejala vacía para indicar que sigue pendiente.</div></div><div class="col-12"><label class="form-label">Observaciones</label><textarea class="form-control" name="observaciones" rows="3" maxlength="1000"><?= e($registro['observaciones'] ?? '') ?></textarea></div></div><?php endif; ?>
                        <?php endif; ?>
                        <div class="form-actions"><a class="btn btn-light" href="?modulo=<?= e($modulo) ?>">Cancelar</a><button class="btn btn-primary" type="submit"><i class="bi bi-check2"></i> Guardar <?= e($modulos[$modulo]['singular']) ?></button></div>
                    </form><?php endif; ?>
                </div>
            <?php endif; ?>
            <footer class="page-footer"><span>Pañol Central · Trabajo Práctico N.º 10</span><span>PHP · MySQL · Bootstrap</span></footer>
        </section>
    </main>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
